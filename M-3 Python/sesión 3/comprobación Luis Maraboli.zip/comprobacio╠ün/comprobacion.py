#valor de las variables
a = 20
b = 30

#multiplicamos las variables 
resultado = a * b #multiplicamos las variables a * b

print(resultado) #imprimimos el resultado en la consola.
