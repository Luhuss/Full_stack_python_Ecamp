import math 

y = 81

raiz_cuadrada_y = math.sqrt(y)

print(f"La raiz cuadrada de {y} es {raiz_cuadrada_y}")



