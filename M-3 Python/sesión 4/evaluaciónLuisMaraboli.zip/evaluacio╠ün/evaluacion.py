# diccionarios
# clave: valor

persona_uno = {'nombre' : 'Juan', 'apellido': 'Perez', 'telefono': 123456789} 

persona_dos = {
    'nombre' : 'Fulanito',
    'apellido': 'Rojo',
    'telefono': 123456789
    }

persona_tres = {'nombre' : 'Maria', 'apellido': 'Rosalez', 'telefono': 123456789} 

lista_persona = [persona_uno, persona_dos, persona_tres]
print(lista_persona)
lista_persona[0]['nombre'] = 'Juanito' # Modificar un valor


