# set
# set de datos o conjuntos de datos, es una estructura de datos que no permite duplicados
# se pueden realizar operaciones de conjuntos como union, intersección, diferencia, etx.
# se utilizan {} para declarar un set de datos

# declarar variables
# snake_case = variable_uno
# camelCase = variableUno
variable_uno = 8 # int (entero)
variable_dos = 10.5 # float (flotante o decimal)
variable_tres = 'ejercicio' # str (string)

# crear set de datos
set_datos = {variable_uno, variable_dos, variable_tres}

lista_datos = [set_datos, False]

print(f'Lista de datos: {lista_datos}')

