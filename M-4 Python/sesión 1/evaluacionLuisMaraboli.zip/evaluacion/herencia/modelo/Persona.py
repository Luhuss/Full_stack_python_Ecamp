class Persona:
    def __init__(self, id, nombre, apellidos, edad):
        self.id        = id
        self.nombre    = nombre
        self.apellidos = apellidos
        self.edad      = edad
        
    def concentrarse(self):
        print("Estoy concentrado")
        
    def viajar(self):
        print("Estoy viajando")