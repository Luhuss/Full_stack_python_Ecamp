# Definimos la clase Persona
class Persona:
    def __init__(self, nombre, apellido, annio):
        # Atributos que almacena el nonbre de la persona
        self.nombre = nombre
        # Atributo que almacena el apellido de la persona
        self.apellido = apellido
        # Atributo que almacena el año 
        self.annio = annio